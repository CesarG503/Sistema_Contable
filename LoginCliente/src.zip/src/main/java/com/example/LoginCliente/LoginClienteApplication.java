package com.example.LoginCliente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginClienteApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginClienteApplication.class, args);
	}
}
function openModal() {
    document.getElementById("partidaModal").style.display = "block"
}

function closeModal() {
    document.getElementById("partidaModal").style.display = "none"
    document.getElementById("partidaForm").reset()
}

function addMovimiento() {
    const container = document.getElementById("movimientos")
    const firstRow = container.querySelector(".movimiento-row")
    const newRow = firstRow.cloneNode(true)
    newRow.querySelectorAll("input, select").forEach((input) => (input.value = ""))
    container.appendChild(newRow)
    attachCalculateListeners()
}

function removeMovimiento(btn) {
    const container = document.getElementById("movimientos")
    if (container.querySelectorAll(".movimiento-row").length > 2) {
        btn.closest(".movimiento-row").remove()
        calculateTotals()
    }
}

function calculateTotals() {
    let totalDebe = 0
    let totalHaber = 0

    document.querySelectorAll(".movimiento-row").forEach((row) => {
        const monto = Number.parseFloat(row.querySelector(".monto-input").value) || 0
        const tipo = row.querySelector(".tipo-select").value

        if (tipo === "D") {
            totalDebe += monto
        } else if (tipo === "H") {
            totalHaber += monto
        }
    })

    document.getElementById("totalDebe").textContent = "$" + totalDebe.toFixed(2)
    document.getElementById("totalHaber").textContent = "$" + totalHaber.toFixed(2)
    document.getElementById("diferencia").textContent = "$" + Math.abs(totalDebe - totalHaber).toFixed(2)
}

function attachCalculateListeners() {
    document.querySelectorAll(".monto-input, .tipo-select").forEach((element) => {
        element.removeEventListener("input", calculateTotals)
        element.addEventListener("input", calculateTotals)
    })
}

function openDetailsModal(button) {
    const asiento = button.getAttribute("data-asiento")
    const fecha = button.getAttribute("data-fecha")
    const concepto = button.getAttribute("data-concepto")
    const movimientosJson = button.getAttribute("data-movimientos")

    console.log("[v0] Opening modal for asiento:", asiento)
    console.log("[v0] Movimientos JSON:", movimientosJson)

    document.getElementById("detalleAsiento").textContent = asiento
    document.getElementById("detalleFecha").textContent = fecha
    document.getElementById("detalleConcepto").textContent = concepto

    const movimientosContainer = document.getElementById("detalleMovimientos")
    movimientosContainer.innerHTML = ""

    let totalDebe = 0
    let totalHaber = 0

    try {
        // Parse the movements data
        const movimientos = JSON.parse(movimientosJson)
        console.log("[v0] Parsed movimientos:", movimientos)

        // Create list of accounts with movements
        const listaCuentas = document.createElement("ul")
        listaCuentas.className = "lista-cuentas"

        movimientos.forEach((mov) => {
            const monto = Number.parseFloat(mov.monto)
            const tipo = mov.tipo === "D" ? "Debe" : "Haber"

            console.log("[v0] Processing movement:", mov.cuenta, monto, tipo)

            if (mov.tipo === "D") {
                totalDebe += monto
            } else {
                totalHaber += monto
            }

            const li = document.createElement("li")
            li.className = "cuenta-item"
            li.innerHTML = `
        <span class="cuenta-nombre">${mov.cuenta}</span>
        <span class="cuenta-movimiento ${mov.tipo === "D" ? "debe" : "haber"}">$${monto.toFixed(2)} (${tipo})</span>
      `
            listaCuentas.appendChild(li)
        })

        movimientosContainer.appendChild(listaCuentas)

        console.log("[v0] Total Debe:", totalDebe, "Total Haber:", totalHaber)

        // Add totals
        const totalesDiv = document.createElement("div")
        totalesDiv.className = "movimiento-totales"
        totalesDiv.innerHTML = `
      <div class="total-row">
        <strong>Total Debe:</strong>
        <span>$${totalDebe.toFixed(2)}</span>
      </div>
      <div class="total-row">
        <strong>Total Haber:</strong>
        <span>$${totalHaber.toFixed(2)}</span>
      </div>
    `
        movimientosContainer.appendChild(totalesDiv)
    } catch (error) {
        console.error("[v0] Error parsing movimientos:", error)
        movimientosContainer.innerHTML = "<p>Error al cargar los movimientos</p>"
    }

    document.getElementById("detallesModal").style.display = "block"
}

function closeDetailsModal() {
    document.getElementById("detallesModal").style.display = "none"
}

// Close modal when clicking outside
window.onclick = (event) => {
    const modal = document.getElementById("detallesModal")
    if (event.target === modal) {
        closeDetailsModal()
    }
}

attachCalculateListeners()

document.getElementById("partidaForm").addEventListener("submit", async (e) => {
    e.preventDefault()

    const concepto = document.getElementById("concepto").value
    const fechaPartida = document.getElementById("fechaPartida").value
    const movimientos = []

    document.querySelectorAll(".movimiento-row").forEach((row) => {
        const idCuenta = row.querySelector(".cuenta-select").value
        const monto = row.querySelector(".monto-input").value
        const tipo = row.querySelector(".tipo-select").value

        if (idCuenta && monto && tipo) {
            movimientos.push({ idCuenta, monto, tipo })
        }
    })

    try {
        const response = await fetch("/partidas/crear", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ concepto, fechaPartida, movimientos }),
        })

        const data = await response.json()

        if (response.ok) {
            alert("Partida creada exitosamente")
            location.reload()
        } else {
            alert(data.error || "Error al crear la partida")
        }
    } catch (error) {
        alert("Error al crear la partida: " + error.message)
    }
})
